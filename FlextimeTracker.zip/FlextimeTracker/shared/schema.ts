import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const timeEntries = pgTable("time_entries", {
  id: serial("id").primaryKey(),
  date: text("date").notNull(),
  weekday: text("weekday").notNull(),
  arrival: text("arrival"),
  lunchOut: text("lunch_out"),
  lunchIn: text("lunch_in"),
  departure: text("departure"),
  extraOut: text("extra_out"),
  extraIn: text("extra_in"),
  vacationComp: text("vacation_comp"),
  notes: text("notes"),
  userId: integer("user_id"),
});

export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  startingBalance: text("starting_balance").notNull().default("+0:00"),
  normalWorkTime: text("normal_work_time").notNull().default("8:00"),
  defaultLunchTime: text("default_lunch_time").notNull().default("0:30"),
  userId: integer("user_id"),
});

export const insertTimeEntrySchema = createInsertSchema(timeEntries).omit({
  id: true,
});

export const insertSettingsSchema = createInsertSchema(settings).omit({
  id: true,
});

export type TimeEntry = typeof timeEntries.$inferSelect;
export type InsertTimeEntry = z.infer<typeof insertTimeEntrySchema>;
export type Settings = typeof settings.$inferSelect;
export type InsertSettings = z.infer<typeof insertSettingsSchema>;

// Client-side types for calculated fields
export interface CalculatedTimeEntry extends TimeEntry {
  lunchDiff: string;
  dailyTime: string;
  extraDiff: string;
  dailyFlex: string;
  balance: string;
  normalTime: string;
}

export interface MonthlyStats {
  workedHours: string;
  monthBalance: string;
  overtime: string;
  flexLeave: string;
}

export interface WeeklyStats {
  [weekNumber: string]: {
    balance: string;
  };
}
