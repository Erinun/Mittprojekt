# Flextime Management App

En modern, webbaserad flextidshanteringsapp som ersätter Excel-baserade lösningar.

## Funktioner

✓ Daglig tidsregistrering med automatiska beräkningar
✓ Månads- och veckosammanfattningar  
✓ Snabbinmatning för vanliga arbetstider
✓ Export till CSV
✓ Responsiv design för alla enheter
✓ Svenska språket

## Cache-rensning

Om du fortfarande ser gammal design eller gul färg, gör en hård uppdatering:

**Windows/Linux:** `Ctrl + Shift + F5`
**Mac:** `Cmd + Shift + R`

Eller öppna sidan i ett inkognitofönster för att se den senaste versionen.

## Utveckling

```bash
npm run dev
```

Appen körs på port 5000.