import { useState, useEffect, useCallback } from 'react';
import { CalculatedTimeEntry, Settings, MonthlyStats, WeeklyStats } from '@shared/schema';
import { FlexTimeCalculator } from '@/lib/flexCalculations';
import { DateHelpers } from '@/lib/dateHelpers';
import { DataManager } from '@/lib/dataManager';
import { useToast } from '@/hooks/use-toast';

export function useFlextime() {
  const { toast } = useToast();
  const [currentYear, setCurrentYear] = useState<number>(() => {
    const { year } = DateHelpers.getCurrentMonthYear();
    return year;
  });
  const [currentMonth, setCurrentMonth] = useState<number>(() => {
    const { month } = DateHelpers.getCurrentMonthYear();
    return month;
  });
  
  const [timeEntries, setTimeEntries] = useState<CalculatedTimeEntry[]>([]);
  const [settings, setSettings] = useState<Settings>(() => DataManager.loadSettings());
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  // Load time entries for current month
  const loadTimeEntries = useCallback(() => {
    const defaultEntries = DateHelpers.generateMonthEntries(currentYear, currentMonth) as CalculatedTimeEntry[];
    const savedEntries = DataManager.loadTimeEntries(currentYear, currentMonth, defaultEntries);
    setTimeEntries(savedEntries);
  }, [currentYear, currentMonth]);

  // Calculate all derived fields for time entries
  const updateCalculations = useCallback(() => {
    let runningBalance = FlexTimeCalculator.parseTime(settings.startingBalance);
    const normalTimeMinutes = FlexTimeCalculator.parseTime(settings.normalWorkTime);

    const updatedEntries = timeEntries.map(entry => {
      const calculatedEntry = { ...entry };

      // Only calculate if there's arrival and departure time
      if (entry.arrival && entry.departure) {
        // Calculate lunch time difference
        const lunchDiff = FlexTimeCalculator.calculateLunchTime(entry.lunchOut, entry.lunchIn);
        calculatedEntry.lunchDiff = FlexTimeCalculator.formatTime(lunchDiff);

        // Calculate daily time
        const dailyTime = FlexTimeCalculator.calculateDailyTime(entry.arrival, entry.departure, lunchDiff);
        calculatedEntry.dailyTime = FlexTimeCalculator.formatTime(dailyTime);

        // Calculate extra time
        const extraTime = FlexTimeCalculator.calculateExtraTime(entry.extraOut, entry.extraIn);
        calculatedEntry.extraDiff = FlexTimeCalculator.formatTime(extraTime);

        // Calculate vacation/comp time
        const vacationComp = FlexTimeCalculator.parseVacationComp(entry.vacationComp);

        // Calculate daily flex
        const dailyFlex = FlexTimeCalculator.calculateDailyFlex(
          dailyTime,
          normalTimeMinutes,
          extraTime,
          vacationComp
        );
        calculatedEntry.dailyFlex = FlexTimeCalculator.formatTime(dailyFlex, true);

        // Update running balance
        runningBalance += dailyFlex;
        calculatedEntry.balance = FlexTimeCalculator.formatTime(runningBalance, true);
      } else {
        // Clear calculated fields if no work time
        calculatedEntry.lunchDiff = '';
        calculatedEntry.dailyTime = '';
        calculatedEntry.extraDiff = '';
        calculatedEntry.dailyFlex = '';
        calculatedEntry.balance = FlexTimeCalculator.formatTime(runningBalance, true);
      }

      // Set normal time
      calculatedEntry.normalTime = FlexTimeCalculator.formatTime(normalTimeMinutes);

      return calculatedEntry;
    });

    setTimeEntries(updatedEntries);
    
    // Save to localStorage
    DataManager.saveTimeEntries(currentYear, currentMonth, updatedEntries);
  }, [timeEntries, settings, currentYear, currentMonth]);

  // Update a specific time entry
  const updateTimeEntry = useCallback((index: number, field: keyof CalculatedTimeEntry, value: string) => {
    setTimeEntries(prev => {
      const updated = [...prev];
      updated[index] = { ...updated[index], [field]: value };
      return updated;
    });
  }, []);

  // Quick entry for common time patterns
  const applyQuickEntry = useCallback((
    entryIndex: number,
    arrival: string,
    departure: string,
    lunchOut: string,
    lunchIn: string
  ) => {
    setTimeEntries(prev => {
      const updated = [...prev];
      updated[entryIndex] = {
        ...updated[entryIndex],
        arrival,
        departure,
        lunchOut,
        lunchIn,
      };
      return updated;
    });
    
    toast({
      title: "Snabbinmatning tillagd",
      description: `Tider ${arrival}-${departure} registrerade`,
    });
  }, [toast]);

  // Apply flex leave for a specific day
  const applyFlexLeave = useCallback((entryIndex: number) => {
    setTimeEntries(prev => {
      const updated = [...prev];
      updated[entryIndex] = {
        ...updated[entryIndex],
        arrival: '08:00',
        departure: '16:30',
        lunchOut: '12:00',
        lunchIn: '12:30',
        extraOut: '08:00',
        extraIn: '16:00',
        notes: 'Flexledigt',
      };
      return updated;
    });
    
    toast({
      title: "Flexledigt registrerat",
      description: "Heldag flexledigt har markerats",
      variant: "default",
    });
  }, [toast]);

  // Update settings
  const updateSettings = useCallback((newSettings: Partial<Settings>) => {
    const updatedSettings = { ...settings, ...newSettings };
    setSettings(updatedSettings);
    DataManager.saveSettings(updatedSettings);
    
    toast({
      title: "Inställningar sparade",
      description: "Dina ändringar har sparats",
    });
  }, [settings, toast]);

  // Navigate to previous month
  const goToPreviousMonth = useCallback(() => {
    const { year, month } = DateHelpers.getPreviousMonth(currentYear, currentMonth);
    setCurrentYear(year);
    setCurrentMonth(month);
  }, [currentYear, currentMonth]);

  // Navigate to next month
  const goToNextMonth = useCallback(() => {
    const { year, month } = DateHelpers.getNextMonth(currentYear, currentMonth);
    setCurrentYear(year);
    setCurrentMonth(month);
  }, [currentYear, currentMonth]);

  // Export current month to CSV
  const exportToCSV = useCallback(() => {
    DataManager.exportToCSV(timeEntries, currentYear, currentMonth);
    
    toast({
      title: "Export slutförd",
      description: "Tidsdata har exporterats till CSV",
    });
  }, [timeEntries, currentYear, currentMonth, toast]);

  // Calculate monthly statistics
  const getMonthlyStats = useCallback((): MonthlyStats => {
    let totalWorked = 0;
    let totalFlex = 0;
    let totalOvertime = 0;
    let totalFlexLeave = 0;

    timeEntries.forEach(entry => {
      if (entry.dailyTime) {
        totalWorked += FlexTimeCalculator.parseTime(entry.dailyTime);
      }
      if (entry.dailyFlex) {
        const flex = FlexTimeCalculator.parseTime(entry.dailyFlex);
        totalFlex += flex;
        if (flex > 0) {
          totalOvertime += flex;
        }
      }
      if (entry.notes?.toLowerCase().includes('flexledigt')) {
        totalFlexLeave += FlexTimeCalculator.parseTime(entry.dailyFlex || '0');
      }
    });

    return {
      workedHours: FlexTimeCalculator.formatTime(totalWorked),
      monthBalance: FlexTimeCalculator.formatTime(totalFlex, true),
      overtime: FlexTimeCalculator.formatTime(totalOvertime),
      flexLeave: FlexTimeCalculator.formatTime(Math.abs(totalFlexLeave)),
    };
  }, [timeEntries]);

  // Calculate weekly statistics
  const getWeeklyStats = useCallback((): WeeklyStats => {
    const weeklyStats: WeeklyStats = {};

    timeEntries.forEach(entry => {
      if (entry.date && entry.dailyFlex) {
        const weekNumber = DateHelpers.getWeekNumber(entry.date, currentYear, currentMonth);
        const flex = FlexTimeCalculator.parseTime(entry.dailyFlex);
        
        if (!weeklyStats[weekNumber]) {
          weeklyStats[weekNumber] = { balance: '' };
        }
        
        const currentWeekBalance = FlexTimeCalculator.parseTime(weeklyStats[weekNumber].balance || '0');
        const newBalance = currentWeekBalance + flex;
        weeklyStats[weekNumber].balance = FlexTimeCalculator.formatTime(newBalance, true);
      }
    });

    return weeklyStats;
  }, [timeEntries, currentYear, currentMonth]);

  // Get current balance (last entry's balance)
  const getCurrentBalance = useCallback((): string => {
    for (let i = timeEntries.length - 1; i >= 0; i--) {
      if (timeEntries[i].balance) {
        return timeEntries[i].balance;
      }
    }
    return settings.startingBalance;
  }, [timeEntries, settings.startingBalance]);

  // Load time entries when month/year changes
  useEffect(() => {
    loadTimeEntries();
  }, [loadTimeEntries]);

  // Update calculations when entries or settings change
  useEffect(() => {
    if (timeEntries.length > 0) {
      updateCalculations();
    }
  }, [settings.startingBalance, settings.normalWorkTime]); // Only recalculate when these specific settings change

  return {
    // State
    currentYear,
    currentMonth,
    timeEntries,
    settings,
    isSettingsOpen,
    
    // Actions
    updateTimeEntry,
    applyQuickEntry,
    applyFlexLeave,
    updateSettings,
    goToPreviousMonth,
    goToNextMonth,
    exportToCSV,
    setIsSettingsOpen,
    
    // Computed values
    monthlyStats: getMonthlyStats(),
    weeklyStats: getWeeklyStats(),
    currentBalance: getCurrentBalance(),
    currentMonthName: DateHelpers.formatMonthYear(currentYear, currentMonth),
  };
}
