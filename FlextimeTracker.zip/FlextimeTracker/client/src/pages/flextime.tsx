import { FlextimeApp } from '@/components/FlextimeApp';

export default function FlextimePage() {
  return <FlextimeApp />;
}
