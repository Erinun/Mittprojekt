export class FlexTimeCalculator {
  /**
   * Parse time string (HH:MM) to minutes
   */
  static parseTime(timeString: string | null | undefined): number {
    if (!timeString || timeString.trim() === '') return 0;
    
    // Handle signed time strings (+/-HH:MM)
    const isNegative = timeString.startsWith('-');
    const cleanTimeString = timeString.replace(/^[+-]/, '');
    
    const [hours, minutes] = cleanTimeString.split(':').map(Number);
    const totalMinutes = (hours || 0) * 60 + (minutes || 0);
    
    return isNegative ? -totalMinutes : totalMinutes;
  }

  /**
   * Format minutes to time string (HH:MM)
   */
  static formatTime(minutes: number, showSign = false): string {
    if (minutes === null || minutes === undefined || isNaN(minutes)) return '';
    
    const sign = minutes < 0 ? '-' : (showSign && minutes > 0 ? '+' : '');
    const absMinutes = Math.abs(minutes);
    const hours = Math.floor(absMinutes / 60);
    const mins = absMinutes % 60;
    
    return `${sign}${hours}:${mins.toString().padStart(2, '0')}`;
  }

  /**
   * Calculate lunch time difference (Lunch IN - Lunch OUT)
   */
  static calculateLunchTime(lunchOut: string | null, lunchIn: string | null): number {
    if (!lunchOut || !lunchIn) return 0;
    return this.parseTime(lunchIn) - this.parseTime(lunchOut);
  }

  /**
   * Calculate daily worked time
   * Formula: Gick - Kom - Lunch +/-
   */
  static calculateDailyTime(
    arrival: string | null,
    departure: string | null,
    lunchDiff: number
  ): number {
    if (!arrival || !departure) return 0;
    
    const totalMinutes = this.parseTime(departure) - this.parseTime(arrival);
    return totalMinutes - lunchDiff;
  }

  /**
   * Calculate extra time difference (X-tra IN - X-tra OUT)
   */
  static calculateExtraTime(extraOut: string | null, extraIn: string | null): number {
    if (!extraOut || !extraIn) return 0;
    return this.parseTime(extraIn) - this.parseTime(extraOut);
  }

  /**
   * Calculate daily flex balance
   * Formula: Tid/dag - Normalarbetstid - Extra tid +/- + Sem/Komp
   */
  static calculateDailyFlex(
    dailyTime: number,
    normalTime: number,
    extraTime: number,
    semComp: number
  ): number {
    return dailyTime - normalTime - extraTime + semComp;
  }

  /**
   * Get CSS class for balance display based on value
   */
  static getBalanceClass(minutes: number): string {
    if (minutes > 0) return 'flex-balance-positive';
    if (minutes < 0) return 'flex-balance-negative';
    return 'flex-balance-neutral';
  }

  /**
   * Validate time format (HH:MM)
   */
  static isValidTimeFormat(timeString: string): boolean {
    if (!timeString) return true; // Empty is valid
    
    const timeRegex = /^[+-]?([0-9]|[01][0-9]|2[0-3]):[0-5][0-9]$/;
    return timeRegex.test(timeString);
  }

  /**
   * Parse vacation/compensation time which can be positive or negative
   */
  static parseVacationComp(vacationComp: string | null): number {
    if (!vacationComp || vacationComp.trim() === '') return 0;
    return this.parseTime(vacationComp);
  }
}
