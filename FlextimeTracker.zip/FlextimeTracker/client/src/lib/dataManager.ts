import { CalculatedTimeEntry, Settings, MonthlyStats, WeeklyStats } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';

export class DataManager {
  private static readonly STORAGE_PREFIX = 'flextime_';

  /**
   * Save data to localStorage
   */
  static save<T>(key: string, data: T): boolean {
    try {
      localStorage.setItem(`${this.STORAGE_PREFIX}${key}`, JSON.stringify(data));
      return true;
    } catch (error) {
      console.error('Failed to save data:', error);
      return false;
    }
  }

  /**
   * Load data from localStorage
   */
  static load<T>(key: string, defaultValue: T): T {
    try {
      const data = localStorage.getItem(`${this.STORAGE_PREFIX}${key}`);
      return data ? JSON.parse(data) : defaultValue;
    } catch (error) {
      console.error('Failed to load data:', error);
      return defaultValue;
    }
  }

  /**
   * Generate storage key for time entries based on year and month
   */
  static getTimeEntriesKey(year: number, month: number): string {
    return `timeEntries_${year}_${month}`;
  }

  /**
   * Save time entries for a specific month
   */
  static saveTimeEntries(year: number, month: number, entries: CalculatedTimeEntry[]): boolean {
    return this.save(this.getTimeEntriesKey(year, month), entries);
  }

  /**
   * Load time entries for a specific month
   */
  static loadTimeEntries(year: number, month: number, defaultEntries: CalculatedTimeEntry[]): CalculatedTimeEntry[] {
    return this.load(this.getTimeEntriesKey(year, month), defaultEntries);
  }

  /**
   * Save settings
   */
  static saveSettings(settings: Settings): boolean {
    return this.save('settings', settings);
  }

  /**
   * Load settings
   */
  static loadSettings(): Settings {
    return this.load('settings', {
      id: 1,
      startingBalance: '+0:00',
      normalWorkTime: '8:00',
      defaultLunchTime: '0:30',
      userId: null,
    });
  }

  /**
   * Export time entries to CSV
   */
  static exportToCSV(timeEntries: CalculatedTimeEntry[], year: number, month: number): void {
    const headers = [
      'Datum',
      'Veckodag',
      'Kom',
      'Lunch UT',
      'Lunch IN',
      'Lunch +/-',
      'Gick',
      'Tid/dag',
      'X-tra UT',
      'X-tra IN',
      '+/-',
      'Sem/Komp',
      'Normal',
      '+/- dag',
      'Saldo',
      'Anmärkningar'
    ];

    const rows = timeEntries.map(entry => [
      entry.date,
      entry.weekday,
      entry.arrival || '',
      entry.lunchOut || '',
      entry.lunchIn || '',
      entry.lunchDiff,
      entry.departure || '',
      entry.dailyTime,
      entry.extraOut || '',
      entry.extraIn || '',
      entry.extraDiff,
      entry.vacationComp || '',
      entry.normalTime,
      entry.dailyFlex,
      entry.balance,
      entry.notes || ''
    ]);

    const csvContent = [headers, ...rows]
      .map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `flextid_${year}_${String(month + 1).padStart(2, '0')}.csv`;
    
    // Trigger download
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    // Clean up
    URL.revokeObjectURL(link.href);
  }

  /**
   * Clear all data
   */
  static clearAllData(): boolean {
    try {
      const keys = Object.keys(localStorage).filter(key => key.startsWith(this.STORAGE_PREFIX));
      keys.forEach(key => localStorage.removeItem(key));
      return true;
    } catch (error) {
      console.error('Failed to clear data:', error);
      return false;
    }
  }

  /**
   * Get all time entries keys (for backup/export purposes)
   */
  static getAllTimeEntriesKeys(): string[] {
    return Object.keys(localStorage)
      .filter(key => key.startsWith(`${this.STORAGE_PREFIX}timeEntries_`))
      .map(key => key.replace(this.STORAGE_PREFIX, ''));
  }

  /**
   * Import data from CSV (placeholder for future implementation)
   */
  static importFromCSV(file: File): Promise<boolean> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          // CSV import logic would go here
          // For now, just resolve as success
          resolve(true);
        } catch (error) {
          reject(error);
        }
      };
      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsText(file);
    });
  }
}
