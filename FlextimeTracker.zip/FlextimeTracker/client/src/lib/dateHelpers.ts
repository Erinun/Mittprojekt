import { format, startOfMonth, endOfMonth, eachDayOfInterval, getWeek, getYear } from 'date-fns';
import { sv } from 'date-fns/locale';

export class DateHelpers {
  private static readonly WEEKDAYS = [
    'Söndag', 'Måndag', 'Tisdag', 'Onsdag', 'Torsdag', 'Fredag', 'Lördag'
  ];

  private static readonly MONTHS = [
    'Januari', 'Februari', 'Mars', 'April', 'Maj', 'Juni',
    'Juli', 'Augusti', 'September', 'Oktober', 'November', 'December'
  ];

  /**
   * Generate time entries for a given month
   */
  static generateMonthEntries(year: number, month: number) {
    const startDate = startOfMonth(new Date(year, month));
    const endDate = endOfMonth(new Date(year, month));
    const days = eachDayOfInterval({ start: startDate, end: endDate });

    return days.map(day => ({
      date: format(day, 'dd MMM', { locale: sv }),
      weekday: this.WEEKDAYS[day.getDay()],
      arrival: '',
      lunchOut: '',
      lunchIn: '',
      departure: '',
      extraOut: '',
      extraIn: '',
      vacationComp: '',
      notes: '',
      // Calculated fields will be added by the calculator
      lunchDiff: '',
      dailyTime: '',
      extraDiff: '',
      dailyFlex: '',
      balance: '',
      normalTime: '',
    }));
  }

  /**
   * Get month name in Swedish
   */
  static getMonthName(month: number): string {
    return this.MONTHS[month] || '';
  }

  /**
   * Get weekday name in Swedish
   */
  static getWeekdayName(dayOfWeek: number): string {
    return this.WEEKDAYS[dayOfWeek] || '';
  }

  /**
   * Format month and year for display
   */
  static formatMonthYear(year: number, month: number): string {
    return `${this.getMonthName(month)} ${year}`;
  }

  /**
   * Get current month and year
   */
  static getCurrentMonthYear(): { year: number; month: number } {
    const now = new Date();
    return {
      year: now.getFullYear(),
      month: now.getMonth()
    };
  }

  /**
   * Get previous month
   */
  static getPreviousMonth(year: number, month: number): { year: number; month: number } {
    if (month === 0) {
      return { year: year - 1, month: 11 };
    }
    return { year, month: month - 1 };
  }

  /**
   * Get next month
   */
  static getNextMonth(year: number, month: number): { year: number; month: number } {
    if (month === 11) {
      return { year: year + 1, month: 0 };
    }
    return { year, month: month + 1 };
  }

  /**
   * Get week number for a date
   */
  static getWeekNumber(dateString: string, year: number, month: number): number {
    const day = parseInt(dateString.split(' ')[0]);
    const date = new Date(year, month, day);
    return getWeek(date, { weekStartsOn: 1, firstWeekContainsDate: 4 });
  }

  /**
   * Check if a date is weekend
   */
  static isWeekend(dateString: string, year: number, month: number): boolean {
    const day = parseInt(dateString.split(' ')[0]);
    const date = new Date(year, month, day);
    const dayOfWeek = date.getDay();
    return dayOfWeek === 0 || dayOfWeek === 6; // Sunday or Saturday
  }

  /**
   * Check if a date is today
   */
  static isToday(dateString: string, year: number, month: number): boolean {
    const day = parseInt(dateString.split(' ')[0]);
    const today = new Date();
    return (
      today.getFullYear() === year &&
      today.getMonth() === month &&
      today.getDate() === day
    );
  }
}
