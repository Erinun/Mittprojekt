import { memo, useRef, useEffect } from 'react';
import { FixedSizeList as List } from 'react-window';
import { motion } from 'framer-motion';
import { ChevronDown, ChevronRight } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { CalculatedTimeEntry } from '@shared/schema';
import { ModernDayCard } from './ModernDayCard';
import { FlexTimeCalculator } from '@/lib/flexCalculations';
import { DateHelpers } from '@/lib/dateHelpers';

interface WeekData {
  weekNumber: number;
  days: CalculatedTimeEntry[];
  weekBalance: string;
  isExpanded: boolean;
}

interface VirtualWeekListProps {
  timeEntries: CalculatedTimeEntry[];
  onUpdateEntry: (index: number, field: keyof CalculatedTimeEntry, value: string) => void;
  currentYear: number;
  currentMonth: number;
  expandedWeeks: Set<number>;
  onToggleWeek: (weekNumber: number) => void;
  selectedDate?: Date;
}

interface WeekRowProps {
  index: number;
  style: any;
  data: {
    weeks: WeekData[];
    onUpdateEntry: (index: number, field: keyof CalculatedTimeEntry, value: string) => void;
    currentYear: number;
    currentMonth: number;
    expandedWeeks: Set<number>;
    onToggleWeek: (weekNumber: number) => void;
    originalTimeEntries: CalculatedTimeEntry[];
  };
}

const WeekRow = memo(({ index, style, data }: WeekRowProps) => {
  const week = data.weeks[index];
  const isExpanded = data.expandedWeeks.has(week.weekNumber);
  
  const getBalanceBadgeClass = (balance: string) => {
    const minutes = FlexTimeCalculator.parseTime(balance);
    if (minutes > 0) return 'flex-badge-positive';
    if (minutes < 0) return 'flex-badge-negative';
    return 'flex-badge-neutral';
  };

  const handleDayUpdate = (dayIndex: number, field: keyof CalculatedTimeEntry, value: string) => {
    // Find the original index of this day in the full time entries array
    const day = week.days[dayIndex];
    const originalIndex = data.originalTimeEntries.findIndex(entry => 
      entry.date === day.date && entry.weekday === day.weekday
    );
    if (originalIndex !== -1) {
      data.onUpdateEntry(originalIndex, field, value);
    }
  };

  return (
    <div style={style} className="px-4 py-2">
      <Collapsible open={isExpanded} onOpenChange={() => data.onToggleWeek(week.weekNumber)}>
        <Card className="bg-card border border-border/50 shadow-sm hover:shadow-md transition-all duration-200">
          <CollapsibleTrigger asChild>
            <motion.div
              whileHover={{ scale: 1.01 }}
              className="w-full cursor-pointer"
            >
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="transition-transform duration-200">
                      {isExpanded ? (
                        <ChevronDown className="h-5 w-5 text-muted-foreground" />
                      ) : (
                        <ChevronRight className="h-5 w-5 text-muted-foreground" />
                      )}
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-foreground">
                        Vecka {week.weekNumber}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {week.days.length} dagar
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Badge className={`flex-badge ${getBalanceBadgeClass(week.weekBalance)}`}>
                      {week.weekBalance}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </motion.div>
          </CollapsibleTrigger>
          
          <CollapsibleContent>
            <div className="px-4 pb-4 space-y-4">
              {week.days.map((day, dayIndex) => (
                <ModernDayCard
                  key={`${day.date}-${dayIndex}`}
                  entry={day}
                  index={dayIndex}
                  onUpdateEntry={handleDayUpdate}
                  currentYear={data.currentYear}
                  currentMonth={data.currentMonth}
                />
              ))}
            </div>
          </CollapsibleContent>
        </Card>
      </Collapsible>
    </div>
  );
});

WeekRow.displayName = 'WeekRow';

export function VirtualWeekList({
  timeEntries,
  onUpdateEntry,
  currentYear,
  currentMonth,
  expandedWeeks,
  onToggleWeek,
  selectedDate
}: VirtualWeekListProps) {
  const listRef = useRef<List>(null);

  // Group entries by week
  const weekGroups = timeEntries.reduce((acc, entry, index) => {
    const weekNumber = DateHelpers.getWeekNumber(entry.date, currentYear, currentMonth);
    
    if (!acc[weekNumber]) {
      acc[weekNumber] = {
        weekNumber,
        days: [],
        weekBalance: '+0:00',
        isExpanded: expandedWeeks.has(weekNumber)
      };
    }
    
    acc[weekNumber].days.push(entry);
    return acc;
  }, {} as Record<number, WeekData>);

  // Calculate week balances
  Object.values(weekGroups).forEach(week => {
    let totalBalance = 0;
    week.days.forEach(day => {
      if (day.dailyFlex) {
        totalBalance += FlexTimeCalculator.parseTime(day.dailyFlex);
      }
    });
    week.weekBalance = FlexTimeCalculator.formatTime(totalBalance, true);
  });

  const weeks = Object.values(weekGroups).sort((a, b) => a.weekNumber - b.weekNumber);

  // Scroll to selected date
  useEffect(() => {
    if (selectedDate && listRef.current) {
      const targetWeek = DateHelpers.getWeekNumber(
        selectedDate.getDate().toString(),
        selectedDate.getFullYear(),
        selectedDate.getMonth()
      );
      const weekIndex = weeks.findIndex(week => week.weekNumber === targetWeek);
      if (weekIndex !== -1) {
        listRef.current.scrollToItem(weekIndex, 'center');
      }
    }
  }, [selectedDate, weeks]);

  const itemData = {
    weeks,
    onUpdateEntry,
    currentYear,
    currentMonth,
    expandedWeeks,
    onToggleWeek,
    originalTimeEntries: timeEntries
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="flex-1 h-full"
    >
      <List
        ref={listRef}
        height={800}
        width={1200}
        itemCount={weeks.length}
        itemSize={expandedWeeks.size > 0 ? 400 : 100}
        itemData={itemData}
        className="scrollbar-thin scrollbar-thumb-muted scrollbar-track-transparent"
      >
        {WeekRow}
      </List>
    </motion.div>
  );
}