import { ChevronLeft, ChevronRight, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface MonthNavigationProps {
  currentMonthName: string;
  onPreviousMonth: () => void;
  onNextMonth: () => void;
  onQuickEntry8to16: () => void;
  onQuickEntry9to17: () => void;
  onFlexLeave: () => void;
  onExportCSV: () => void;
}

export function MonthNavigation({
  currentMonthName,
  onPreviousMonth,
  onNextMonth,
  onQuickEntry8to16,
  onQuickEntry9to17,
  onFlexLeave,
  onExportCSV,
}: MonthNavigationProps) {
  return (
    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 space-y-4 sm:space-y-0">
      <div className="flex items-center space-x-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={onPreviousMonth}
          className="text-muted-foreground hover:text-primary hover:bg-primary/10"
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <h2 className="text-2xl font-semibold text-foreground">
          {currentMonthName}
        </h2>
        <Button
          variant="ghost"
          size="icon"
          onClick={onNextMonth}
          className="text-muted-foreground hover:text-primary hover:bg-primary/10"
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
      
      {/* Quick Actions */}
      <div className="flex flex-wrap items-center gap-2">
        <Button
          size="sm"
          onClick={onQuickEntry8to16}
          className="bg-primary text-primary-foreground hover:bg-primary/90"
        >
          8:00-16:30
        </Button>
        <Button
          variant="secondary"
          size="sm"
          onClick={onQuickEntry9to17}
          className="text-secondary-foreground hover:bg-secondary/80"
        >
          9:00-17:00
        </Button>
        <Button
          size="sm"
          onClick={onFlexLeave}
          className="bg-warning text-white hover:bg-warning/90"
        >
          Flexledigt
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={onExportCSV}
          className="text-success border-success hover:bg-success hover:text-white"
        >
          <Download className="h-4 w-4 mr-1" />
          Export
        </Button>
      </div>
    </div>
  );
}
