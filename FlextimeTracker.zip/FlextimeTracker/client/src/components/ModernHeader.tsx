import { motion } from 'framer-motion';
import { Calendar, ChevronLeft, ChevronRight, Settings, Sun, Moon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { FlexTimeCalculator } from '@/lib/flexCalculations';

interface ModernHeaderProps {
  currentMonthName: string;
  currentBalance: string;
  onPreviousMonth: () => void;
  onNextMonth: () => void;
  onOpenSettings: () => void;
  isDarkMode?: boolean;
  onToggleDarkMode?: () => void;
}

export function ModernHeader({
  currentMonthName,
  currentBalance,
  onPreviousMonth,
  onNextMonth,
  onOpenSettings,
  isDarkMode = false,
  onToggleDarkMode
}: ModernHeaderProps) {
  const balanceMinutes = FlexTimeCalculator.parseTime(currentBalance);
  
  const getBalanceBadgeClass = () => {
    if (balanceMinutes > 0) return 'flex-badge-positive';
    if (balanceMinutes < 0) return 'flex-badge-negative';
    return 'flex-badge-neutral';
  };

  return (
    <motion.header 
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="sticky top-0 z-50 bg-card/80 backdrop-blur-xl border-b border-border/50 shadow-sm"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Left Section */}
          <div className="flex items-center space-x-6">
            <motion.div
              whileHover={{ scale: 1.02 }}
              className="flex items-center space-x-3"
            >
              <div className="p-2 bg-transparent rounded-xl">
                <Calendar className="h-6 w-6" style={{ color: 'var(--primary)' }} />
              </div>
              <div>
                <h1 className="text-xl sm:text-2xl font-bold text-heading">
                  Flextidshantering
                </h1>
                <p className="text-sm text-label hidden sm:block">
                  Modern tidsregistrering
                </p>
              </div>
            </motion.div>
          </div>

          {/* Center Section - Month Navigation */}
          <div className="flex items-center space-x-4">
            <motion.div whileTap={{ scale: 0.95 }}>
              <Button
                variant="ghost"
                size="icon"
                onClick={onPreviousMonth}
                className="btn-secondary rounded-xl"
                style={{ 
                  color: 'var(--text-secondary)',
                  borderColor: 'var(--border)'
                }}
              >
                <ChevronLeft className="h-5 w-5" />
              </Button>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              key={currentMonthName}
              className="min-w-[200px] text-center"
            >
              <h2 className="text-lg sm:text-xl font-semibold text-heading">
                {currentMonthName}
              </h2>
            </motion.div>
            
            <motion.div whileTap={{ scale: 0.95 }}>
              <Button
                variant="ghost"
                size="icon"
                onClick={onNextMonth}
                className="btn-secondary rounded-xl"
                style={{ 
                  color: 'var(--text-secondary)',
                  borderColor: 'var(--border)'
                }}
              >
                <ChevronRight className="h-5 w-5" />
              </Button>
            </motion.div>
          </div>

          {/* Right Section */}
          <div className="flex items-center space-x-4">
            {/* Balance Display */}
            <motion.div
              whileHover={{ scale: 1.02 }}
              className="hidden sm:flex items-center space-x-3 px-4 py-2 bg-muted/50 rounded-xl"
            >
              <span className="text-sm font-medium text-muted-foreground">
                Saldo:
              </span>
              <Badge className={`flex-badge ${getBalanceBadgeClass()}`}>
                {currentBalance}
              </Badge>
            </motion.div>

            {/* Dark Mode Toggle */}
            {onToggleDarkMode && (
              <motion.div whileTap={{ scale: 0.95 }}>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={onToggleDarkMode}
                  className="rounded-xl hover:bg-primary/10 text-muted-foreground hover:text-primary"
                >
                  {isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
                </Button>
              </motion.div>
            )}

            {/* Settings Button */}
            <motion.div whileTap={{ scale: 0.95 }}>
              <Button
                variant="ghost"
                size="icon"
                onClick={onOpenSettings}
                className="rounded-xl hover:bg-primary/10 text-muted-foreground hover:text-primary"
              >
                <Settings className="h-5 w-5" />
              </Button>
            </motion.div>
          </div>
        </div>

        {/* Mobile Balance Display */}
        <div className="sm:hidden pb-4">
          <div className="flex items-center justify-center space-x-3 px-4 py-2 bg-muted/50 rounded-xl">
            <span className="text-sm font-medium text-muted-foreground">
              Totalt saldo:
            </span>
            <Badge className={`flex-badge ${getBalanceBadgeClass()}`}>
              {currentBalance}
            </Badge>
          </div>
        </div>
      </div>
    </motion.header>
  );
}