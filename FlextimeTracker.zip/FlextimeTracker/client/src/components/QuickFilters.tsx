import { motion } from 'framer-motion';
import { Filter, Calendar, Clock, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';

interface QuickFiltersProps {
  activeFilters: string[];
  onToggleFilter: (filter: string) => void;
  onOpenQuickSearch: () => void;
}

export function QuickFilters({ activeFilters, onToggleFilter, onOpenQuickSearch }: QuickFiltersProps) {
  const filters = [
    {
      id: 'empty-fields',
      label: 'Endast tomma fält',
      icon: Clock,
      description: 'Visa dagar med saknade tider'
    },
    {
      id: 'last-30-days',
      label: 'Senaste 30 dagar',
      icon: Calendar,
      description: 'Filtrera till senaste månaden'
    },
    {
      id: 'current-month',
      label: 'Denna månad',
      icon: Calendar,
      description: 'Visa endast aktuell månad'
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="mb-6"
    >
      <Card className="bg-card border border-border/50 shadow-sm">
        <CardContent className="p-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center space-x-2">
              <Filter className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium text-muted-foreground">Filter:</span>
            </div>
            
            {filters.map((filter, index) => {
              const isActive = activeFilters.includes(filter.id);
              const Icon = filter.icon;
              
              return (
                <motion.div
                  key={filter.id}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Button
                    variant={isActive ? "default" : "outline"}
                    size="sm"
                    onClick={() => onToggleFilter(filter.id)}
                    className={`
                      rounded-xl transition-all duration-200
                      ${isActive 
                        ? 'bg-primary text-primary-foreground shadow-md' 
                        : 'hover:bg-muted'
                      }
                    `}
                  >
                    <Icon className="h-4 w-4 mr-2" />
                    {filter.label}
                  </Button>
                </motion.div>
              );
            })}
            
            <div className="flex-1" />
            
            {/* Quick Search */}
            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Button
                variant="outline"
                size="sm"
                onClick={onOpenQuickSearch}
                className="rounded-xl hover:bg-muted"
              >
                <Search className="h-4 w-4 mr-2" />
                <span className="hidden sm:inline">Sök datum</span>
                <Badge variant="secondary" className="ml-2 text-xs">
                  ⌘K
                </Badge>
              </Button>
            </motion.div>
            
            {/* Active Filter Count */}
            {activeFilters.length > 0 && (
              <motion.div
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: 1, scale: 1 }}
              >
                <Badge variant="secondary" className="rounded-full">
                  {activeFilters.length} aktiva
                </Badge>
              </motion.div>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}