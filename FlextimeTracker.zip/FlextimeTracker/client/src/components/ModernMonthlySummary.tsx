import { motion } from 'framer-motion';
import { TrendingUp, Clock, Coffee, Calendar } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { MonthlyStats } from '@shared/schema';
import { FlexTimeCalculator } from '@/lib/flexCalculations';

interface ModernMonthlySummaryProps {
  stats: MonthlyStats;
}

export function ModernMonthlySummary({ stats }: ModernMonthlySummaryProps) {
  const monthBalanceMinutes = FlexTimeCalculator.parseTime(stats.monthBalance);
  
  const summaryItems = [
    {
      icon: Clock,
      label: 'Arbetade timmar',
      value: stats.workedHours,
      color: 'text-blue-600 dark:text-blue-400',
      bgColor: 'bg-blue-50 dark:bg-blue-900/20'
    },
    {
      icon: TrendingUp,
      label: 'Månadssaldo',
      value: stats.monthBalance,
      color: monthBalanceMinutes >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400',
      bgColor: monthBalanceMinutes >= 0 ? 'bg-emerald-50 dark:bg-emerald-900/20' : 'bg-red-50 dark:bg-red-900/20'
    },
    {
      icon: Calendar,
      label: 'Övertid',
      value: stats.overtime,
      color: 'text-amber-600 dark:text-amber-400',
      bgColor: 'bg-amber-50 dark:bg-amber-900/20'
    },
    {
      icon: Coffee,
      label: 'Flexledigt',
      value: stats.flexLeave,
      color: 'text-purple-600 dark:text-purple-400',
      bgColor: 'bg-purple-50 dark:bg-purple-900/20'
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="mb-8"
    >
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {summaryItems.map((item, index) => (
          <motion.div
            key={item.label}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
            whileHover={{ scale: 1.02 }}
          >
            <Card className="stat-card h-full">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">
                      {item.label}
                    </p>
                    <p className={`text-2xl font-bold ${item.color}`}>
                      {item.value}
                    </p>
                  </div>
                  <div className={`p-3 rounded-xl ${item.bgColor}`}>
                    <item.icon className={`h-6 w-6 ${item.color}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}