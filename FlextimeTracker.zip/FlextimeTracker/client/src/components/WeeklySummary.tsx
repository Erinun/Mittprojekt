import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { WeeklyStats } from '@shared/schema';
import { FlexTimeCalculator } from '@/lib/flexCalculations';

interface WeeklySummaryProps {
  stats: WeeklyStats;
}

export function WeeklySummary({ stats }: WeeklySummaryProps) {
  // Get all week numbers and sort them
  const weekNumbers = Object.keys(stats)
    .map(Number)
    .sort((a, b) => a - b);

  // Calculate monthly total
  const monthlyTotal = weekNumbers.reduce((total, weekNum) => {
    const weekBalance = FlexTimeCalculator.parseTime(stats[weekNum].balance);
    return total + weekBalance;
  }, 0);

  const getBalanceClass = (balance: string) => {
    const minutes = FlexTimeCalculator.parseTime(balance);
    return FlexTimeCalculator.getBalanceClass(minutes);
  };

  return (
    <Card className="bg-surface border border-border shadow-sm">
      <CardHeader className="px-6 py-4 border-b border-border">
        <CardTitle className="text-lg font-semibold text-foreground">
          Veckosammanfattning
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          {weekNumbers.map(weekNum => (
            <div key={weekNum} className="text-center">
              <p className="text-sm font-medium text-muted-foreground mb-1">
                Vecka {weekNum}
              </p>
              <p className={`text-lg font-semibold ${getBalanceClass(stats[weekNum].balance)}`}>
                {stats[weekNum].balance || '-'}
              </p>
            </div>
          ))}
          
          {/* Fill remaining slots with empty weeks if less than 4 weeks */}
          {weekNumbers.length < 4 && Array.from({ length: 4 - weekNumbers.length }).map((_, index) => (
            <div key={`empty-${index}`} className="text-center">
              <p className="text-sm font-medium text-muted-foreground mb-1">
                Vecka -
              </p>
              <p className="text-lg font-semibold text-muted-foreground">-</p>
            </div>
          ))}
          
          {/* Monthly total */}
          <div className="text-center bg-muted/50 rounded-lg p-3">
            <p className="text-sm font-medium text-muted-foreground mb-1">
              Månadstotal
            </p>
            <p className={`text-lg font-semibold ${getBalanceClass(FlexTimeCalculator.formatTime(monthlyTotal, true))}`}>
              {FlexTimeCalculator.formatTime(monthlyTotal, true)}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
