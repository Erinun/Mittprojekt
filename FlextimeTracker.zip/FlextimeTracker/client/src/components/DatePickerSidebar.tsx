import { motion } from 'framer-motion';
import { Calendar, ChevronLeft, ChevronRight } from 'lucide-react';
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface DatePickerSidebarProps {
  currentYear: number;
  currentMonth: number;
  onDateSelect: (date: Date) => void;
  onMonthChange: (year: number, month: number) => void;
  currentBalance: string;
}

export function DatePickerSidebar({
  currentYear,
  currentMonth,
  onDateSelect,
  onMonthChange,
  currentBalance
}: DatePickerSidebarProps) {
  const [selectedDate, setSelectedDate] = useState(new Date());

  const monthNames = [
    'Januari', 'Februari', 'Mars', 'April', 'Maj', 'Juni',
    'Juli', 'Augusti', 'September', 'Oktober', 'November', 'December'
  ];

  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const firstDay = new Date(currentYear, currentMonth, 1).getDay();
  const adjustedFirstDay = firstDay === 0 ? 6 : firstDay - 1; // Måndag = 0

  const handleDateClick = (day: number) => {
    const date = new Date(currentYear, currentMonth, day);
    setSelectedDate(date);
    onDateSelect(date);
  };

  const handlePrevMonth = () => {
    if (currentMonth === 0) {
      onMonthChange(currentYear - 1, 11);
    } else {
      onMonthChange(currentYear, currentMonth - 1);
    }
  };

  const handleNextMonth = () => {
    if (currentMonth === 11) {
      onMonthChange(currentYear + 1, 0);
    } else {
      onMonthChange(currentYear, currentMonth + 1);
    }
  };

  return (
    <motion.aside
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      className="hidden lg:block w-80 border-r border-border bg-muted/30 p-6"
    >
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-primary/10 rounded-xl">
            <Calendar className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-foreground">Kalender</h2>
            <p className="text-sm text-muted-foreground">Hoppa till datum</p>
          </div>
        </div>

        {/* Current Balance */}
        <Card className="bg-gradient-to-r from-primary/5 to-primary/10 border-primary/20">
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-1">Aktuellt saldo</p>
              <Badge className="text-lg font-bold">
                {currentBalance}
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* Calendar */}
        <Card className="bg-card">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base">
                {monthNames[currentMonth]} {currentYear}
              </CardTitle>
              <div className="flex space-x-1">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handlePrevMonth}
                  className="h-8 w-8 rounded-lg hover:bg-primary/10"
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handleNextMonth}
                  className="h-8 w-8 rounded-lg hover:bg-primary/10"
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-4 pt-0">
            {/* Calendar Grid */}
            <div className="space-y-2">
              {/* Weekday Headers */}
              <div className="grid grid-cols-7 gap-1 mb-2">
                {['Mån', 'Tis', 'Ons', 'Tor', 'Fre', 'Lör', 'Sön'].map(day => (
                  <div key={day} className="text-xs font-medium text-muted-foreground text-center py-2">
                    {day}
                  </div>
                ))}
              </div>
              
              {/* Calendar Days */}
              <div className="grid grid-cols-7 gap-1">
                {/* Empty cells for days before month starts */}
                {Array.from({ length: adjustedFirstDay }).map((_, index) => (
                  <div key={`empty-${index}`} className="h-8" />
                ))}
                
                {/* Days of the month */}
                {Array.from({ length: daysInMonth }).map((_, index) => {
                  const day = index + 1;
                  const date = new Date(currentYear, currentMonth, day);
                  const isSelected = selectedDate.getDate() === day && 
                                   selectedDate.getMonth() === currentMonth && 
                                   selectedDate.getFullYear() === currentYear;
                  const isToday = new Date().toDateString() === date.toDateString();
                  
                  return (
                    <motion.button
                      key={day}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => handleDateClick(day)}
                      className={`
                        h-8 w-8 text-sm rounded-lg transition-all duration-200
                        ${isSelected 
                          ? 'bg-primary text-primary-foreground font-semibold' 
                          : isToday 
                          ? 'bg-primary/20 text-primary font-medium' 
                          : 'hover:bg-muted text-foreground'
                        }
                      `}
                    >
                      {day}
                    </motion.button>
                  );
                })}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Navigation */}
        <Card className="bg-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Snabbnavigation</CardTitle>
          </CardHeader>
          <CardContent className="p-4 pt-0 space-y-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleDateClick(new Date().getDate())}
              className="w-full justify-start rounded-xl"
            >
              <Calendar className="h-4 w-4 mr-2" />
              Idag
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => onMonthChange(new Date().getFullYear(), new Date().getMonth())}
              className="w-full justify-start rounded-xl"
            >
              <Calendar className="h-4 w-4 mr-2" />
              Aktuell månad
            </Button>
          </CardContent>
        </Card>
      </div>
    </motion.aside>
  );
}