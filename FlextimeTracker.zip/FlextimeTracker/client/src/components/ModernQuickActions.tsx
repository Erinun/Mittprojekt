import { motion } from 'framer-motion';
import { Clock, Coffee, Download, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface ModernQuickActionsProps {
  onQuickEntry8to16: () => void;
  onQuickEntry9to17: () => void;
  onFlexLeave: () => void;
  onExportCSV: () => void;
}

export function ModernQuickActions({
  onQuickEntry8to16,
  onQuickEntry9to17,
  onFlexLeave,
  onExportCSV
}: ModernQuickActionsProps) {
  const actions = [
    {
      icon: Clock,
      label: 'Idag 8:00-16:30',
      onClick: onQuickEntry8to16,
      variant: 'default' as const,
      className: 'bg-primary hover:bg-primary/90 text-primary-foreground'
    },
    {
      icon: Clock,
      label: 'Idag 9:00-17:00',
      onClick: onQuickEntry9to17,
      variant: 'secondary' as const,
      className: 'bg-secondary hover:bg-secondary/80 text-secondary-foreground'
    },
    {
      icon: Coffee,
      label: 'Flexledigt idag',
      onClick: onFlexLeave,
      variant: 'outline' as const,
      className: 'border-orange-300 text-orange-600 hover:bg-orange-50 dark:border-orange-700 dark:text-orange-400 dark:hover:bg-orange-900/20'
    },
    {
      icon: Download,
      label: 'Exportera CSV',
      onClick: onExportCSV,
      variant: 'outline' as const,
      className: 'border-emerald-300 text-emerald-600 hover:bg-emerald-50 dark:border-emerald-700 dark:text-emerald-400 dark:hover:bg-emerald-900/20 ml-auto'
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="flex flex-wrap items-center gap-3 p-6 bg-card rounded-2xl shadow-sm border border-border/50 mb-8"
    >
      <div className="flex items-center space-x-2 mr-4">
        <Zap className="h-5 w-5 text-primary" />
        <span className="text-sm font-medium text-muted-foreground">Snabbåtgärder:</span>
      </div>
      
      {actions.map((action, index) => (
        <motion.div
          key={action.label}
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.2, delay: index * 0.1 }}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className={action.label === 'Exportera CSV' ? 'ml-auto' : ''}
        >
          <Button
            variant={action.variant}
            size="sm"
            onClick={action.onClick}
            className={`rounded-xl ${action.className} transition-all duration-200`}
          >
            <action.icon className="h-4 w-4 mr-2" />
            {action.label}
          </Button>
        </motion.div>
      ))}
    </motion.div>
  );
}