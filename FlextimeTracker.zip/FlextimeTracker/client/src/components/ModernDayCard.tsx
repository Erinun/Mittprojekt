import { motion } from 'framer-motion';
import { Clock, Calendar, Coffee } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { CalculatedTimeEntry } from '@shared/schema';
import { FlexTimeCalculator } from '@/lib/flexCalculations';
import { DateHelpers } from '@/lib/dateHelpers';

interface ModernDayCardProps {
  entry: CalculatedTimeEntry;
  index: number;
  onUpdateEntry: (index: number, field: keyof CalculatedTimeEntry, value: string) => void;
  currentYear: number;
  currentMonth: number;
}

export function ModernDayCard({ 
  entry, 
  index, 
  onUpdateEntry, 
  currentYear, 
  currentMonth 
}: ModernDayCardProps) {
  const handleInputChange = (field: keyof CalculatedTimeEntry, value: string) => {
    onUpdateEntry(index, field, value);
  };

  const getFlexBadgeVariant = (flex: string) => {
    const minutes = FlexTimeCalculator.parseTime(flex);
    if (minutes > 0) return 'flex-badge-positive';
    if (minutes < 0) return 'flex-badge-negative';
    return 'flex-badge-neutral';
  };

  const isToday = DateHelpers.isToday(entry.date, currentYear, currentMonth);
  const isWeekend = DateHelpers.isWeekend(entry.date, currentYear, currentMonth);
  const isFlexLeave = entry.notes?.toLowerCase().includes('flexledigt');

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, delay: index * 0.02 }}
      whileHover={{ scale: 1.01 }}
      className="w-full"
    >
      <Card className={`flex-card ${isToday ? 'ring-2 ring-primary/30' : ''} ${isWeekend ? 'bg-slate-50 dark:bg-slate-900/50' : ''} ${isFlexLeave ? 'bg-orange-50 dark:bg-orange-900/20' : ''}`}>
        <CardContent className="p-0">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-primary/10 rounded-xl">
                <Calendar className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-foreground">{entry.date}</h3>
                <p className="text-sm text-muted-foreground">{entry.weekday}</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              {entry.dailyFlex && (
                <Badge className={`flex-badge ${getFlexBadgeVariant(entry.dailyFlex)}`}>
                  {entry.dailyFlex}
                </Badge>
              )}
              {entry.balance && (
                <Badge className={`flex-badge ${getFlexBadgeVariant(entry.balance)}`}>
                  Saldo: {entry.balance}
                </Badge>
              )}
            </div>
          </div>

          {/* Time Inputs Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <div className="space-y-2">
              <Label className="text-sm font-medium flex items-center space-x-1">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <span>Kom</span>
              </Label>
              <Input
                type="time"
                value={entry.arrival || ''}
                onChange={(e) => handleInputChange('arrival', e.target.value)}
                className="rounded-xl border-border/50 focus:ring-primary/20"
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-sm font-medium flex items-center space-x-1">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <span>Gick</span>
              </Label>
              <Input
                type="time"
                value={entry.departure || ''}
                onChange={(e) => handleInputChange('departure', e.target.value)}
                className="rounded-xl border-border/50 focus:ring-primary/20"
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-sm font-medium flex items-center space-x-1">
                <Coffee className="h-4 w-4 text-muted-foreground" />
                <span>Lunch UT</span>
              </Label>
              <Input
                type="time"
                value={entry.lunchOut || ''}
                onChange={(e) => handleInputChange('lunchOut', e.target.value)}
                className="rounded-xl border-border/50 focus:ring-primary/20"
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-sm font-medium flex items-center space-x-1">
                <Coffee className="h-4 w-4 text-muted-foreground" />
                <span>Lunch IN</span>
              </Label>
              <Input
                type="time"
                value={entry.lunchIn || ''}
                onChange={(e) => handleInputChange('lunchIn', e.target.value)}
                className="rounded-xl border-border/50 focus:ring-primary/20"
              />
            </div>
          </div>

          {/* Stats Row */}
          {entry.dailyTime && (
            <div className="flex items-center justify-between py-4 px-4 bg-muted/30 rounded-xl mb-4">
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Tid/dag</p>
                <p className="text-sm font-semibold text-foreground">{entry.dailyTime}</p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Lunch</p>
                <p className="text-sm font-semibold text-foreground">{entry.lunchDiff || '-'}</p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Normal</p>
                <p className="text-sm font-semibold text-foreground">{entry.normalTime}</p>
              </div>
            </div>
          )}

          {/* Notes */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">Anteckningar</Label>
            <Input
              type="text"
              value={entry.notes || ''}
              onChange={(e) => handleInputChange('notes', e.target.value)}
              placeholder="Lägg till en anteckning..."
              className="rounded-xl border-border/50 focus:ring-primary/20"
            />
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}