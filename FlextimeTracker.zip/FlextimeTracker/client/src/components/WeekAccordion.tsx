import { motion } from 'framer-motion';
import { Badge } from '@/components/ui/badge';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { DayCard } from './DayCard';
import { WeekDayNav } from './WeekDayNav';
import { CalculatedTimeEntry } from '@shared/schema';
import { FlexTimeCalculator } from '@/lib/flexCalculations';

interface WeekAccordionProps {
  weekNumber: number;
  weekDays: CalculatedTimeEntry[];
  weekBalance: string;
  onUpdateEntry: (dayIndex: number, field: keyof CalculatedTimeEntry, value: string) => void;
  currentYear: number;
  currentMonth: number;
  isExpanded?: boolean;
  onToggle?: () => void;
}

export function WeekAccordion({
  weekNumber,
  weekDays,
  weekBalance,
  onUpdateEntry,
  currentYear,
  currentMonth,
  isExpanded = false,
  onToggle
}: WeekAccordionProps) {
  const getBalanceBadgeClass = (balance: string) => {
    const minutes = FlexTimeCalculator.parseTime(balance);
    if (minutes > 0) return 'bg-green-50 text-green-700 border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-800';
    if (minutes < 0) return 'bg-red-50 text-red-700 border-red-200 dark:bg-red-900/20 dark:text-red-400 dark:border-red-800';
    return 'bg-gray-50 text-gray-600 border-gray-200 dark:bg-gray-800/20 dark:text-gray-400 dark:border-gray-700';
  };

  const scrollToDay = (dayIndex: number) => {
    const dayElement = document.getElementById(`day-${weekNumber}-${dayIndex}`);
    if (dayElement) {
      dayElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  // Säkerställ att vi har alla 7 dagar (måndag till söndag)
  const allWeekDays = Array(7).fill(null).map((_, index) => {
    const existingDay = weekDays.find(day => {
      const dayNum = parseInt(day.date.split(' ')[0]);
      const date = new Date(currentYear, currentMonth, dayNum);
      const dayOfWeek = date.getDay();
      const mondayIndex = dayOfWeek === 0 ? 6 : dayOfWeek - 1; // Måndag = 0
      return mondayIndex === index;
    });

    if (existingDay) {
      return existingDay;
    }

    // Skapa en tom dag för saknade dagar
    const mondayOfWeek = new Date(currentYear, currentMonth, 1);
    // Hitta första måndag
    while (mondayOfWeek.getDay() !== 1) {
      mondayOfWeek.setDate(mondayOfWeek.getDate() + 1);
    }
    // Lägg till veckor för att hitta rätt vecka
    mondayOfWeek.setDate(mondayOfWeek.getDate() + (weekNumber - 1) * 7 + index);
    
    const dayNum = mondayOfWeek.getDate();
    const weekdayNames = ['Måndag', 'Tisdag', 'Onsdag', 'Torsdag', 'Fredag', 'Lördag', 'Söndag'];
    
    return {
      id: 0,
      date: `${dayNum} ${weekdayNames[index]}`,
      weekday: weekdayNames[index],
      arrival: '',
      departure: '',
      lunchOut: '',
      lunchIn: '',
      extraOut: '',
      extraIn: '',
      vacationComp: '',
      notes: '',
      normalTime: '8:00',
      lunchDiff: '0:00',
      dailyTime: '0:00',
      extraDiff: '0:00',
      dailyFlex: '0:00',
      balance: '0:00'
    } as CalculatedTimeEntry;
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full"
    >
      <Accordion type="single" collapsible value={isExpanded ? `week-${weekNumber}` : undefined}>
        <AccordionItem value={`week-${weekNumber}`} className="card-surface">
          <AccordionTrigger 
            className="px-6 py-4 hover:no-underline"
            onClick={onToggle}
          >
            <div className="flex items-center justify-between w-full mr-4">
              <div className="flex items-center space-x-4">
                <h3 className="text-lg font-semibold text-foreground">
                  Vecka {weekNumber}
                </h3>
                <span className="text-sm text-muted-foreground">
                  {weekDays.length} av 7 dagar
                </span>
              </div>
              
              <Badge className={`${getBalanceBadgeClass(weekBalance)} px-3 py-1 rounded-full font-medium border`}>
                {weekBalance}
              </Badge>
            </div>
          </AccordionTrigger>
          
          <AccordionContent className="px-6 pb-6">
            {/* Week Day Navigation */}
            <div className="mb-4">
              <WeekDayNav 
                weekDays={allWeekDays}
                onDayClick={scrollToDay}
              />
            </div>
            
            {/* All 7 Days */}
            <div className="space-y-4">
              {allWeekDays.map((day, dayIndex) => (
                <div key={`${day.date}-${dayIndex}`} id={`day-${weekNumber}-${dayIndex}`}>
                  <DayCard
                    day={day}
                    dayIndex={dayIndex}
                    onUpdateEntry={onUpdateEntry}
                    currentYear={currentYear}
                    currentMonth={currentMonth}
                  />
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </motion.div>
  );
}