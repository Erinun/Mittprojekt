import { Clock, Scale, Plus, Minus } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { MonthlyStats } from '@shared/schema';
import { FlexTimeCalculator } from '@/lib/flexCalculations';

interface MonthlySummaryProps {
  stats: MonthlyStats;
}

export function MonthlySummary({ stats }: MonthlySummaryProps) {
  const monthBalanceMinutes = FlexTimeCalculator.parseTime(stats.monthBalance);
  const monthBalanceClass = FlexTimeCalculator.getBalanceClass(monthBalanceMinutes);

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
      <Card className="bg-surface border border-border shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Arbetade timmar</p>
              <p className="text-2xl font-semibold text-foreground">{stats.workedHours}</p>
            </div>
            <Clock className="h-8 w-8 text-primary" />
          </div>
        </CardContent>
      </Card>
      
      <Card className="bg-surface border border-border shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Månadssaldo</p>
              <p className={`text-2xl font-semibold ${monthBalanceClass}`}>
                {stats.monthBalance}
              </p>
            </div>
            <Scale className="h-8 w-8 text-success" />
          </div>
        </CardContent>
      </Card>
      
      <Card className="bg-surface border border-border shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Övertid</p>
              <p className="text-2xl font-semibold text-warning">{stats.overtime}</p>
            </div>
            <Plus className="h-8 w-8 text-warning" />
          </div>
        </CardContent>
      </Card>
      
      <Card className="bg-surface border border-border shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Flexledigt</p>
              <p className="text-2xl font-semibold text-danger">{stats.flexLeave}</p>
            </div>
            <Minus className="h-8 w-8 text-danger" />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
