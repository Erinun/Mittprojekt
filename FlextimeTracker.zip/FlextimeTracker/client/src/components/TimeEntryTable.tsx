import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CalculatedTimeEntry } from '@shared/schema';
import { FlexTimeCalculator } from '@/lib/flexCalculations';
import { DateHelpers } from '@/lib/dateHelpers';

interface TimeEntryTableProps {
  timeEntries: CalculatedTimeEntry[];
  onUpdateEntry: (index: number, field: keyof CalculatedTimeEntry, value: string) => void;
  currentYear: number;
  currentMonth: number;
}

export function TimeEntryTable({ 
  timeEntries, 
  onUpdateEntry, 
  currentYear, 
  currentMonth 
}: TimeEntryTableProps) {
  const handleInputChange = (index: number, field: keyof CalculatedTimeEntry, value: string) => {
    // Validate time format for time inputs
    if (['arrival', 'lunchOut', 'lunchIn', 'departure', 'extraOut', 'extraIn'].includes(field)) {
      if (value && !FlexTimeCalculator.isValidTimeFormat(value)) {
        return; // Don't update if invalid format
      }
    }
    
    onUpdateEntry(index, field, value);
  };

  const getRowClassName = (entry: CalculatedTimeEntry, index: number) => {
    let className = "hover:bg-muted/50 transition-colors";
    
    // Highlight weekends
    if (DateHelpers.isWeekend(entry.date, currentYear, currentMonth)) {
      className += " bg-muted/20";
    }
    
    // Highlight today
    if (DateHelpers.isToday(entry.date, currentYear, currentMonth)) {
      className += " bg-primary/5 border-l-4 border-l-primary";
    }
    
    // Highlight flex leave days
    if (entry.notes?.toLowerCase().includes('flexledigt')) {
      className += " bg-danger/5";
    }
    
    return className;
  };

  const getBalanceClass = (balance: string) => {
    const minutes = FlexTimeCalculator.parseTime(balance);
    return FlexTimeCalculator.getBalanceClass(minutes);
  };

  return (
    <Card className="bg-surface border border-border shadow-sm overflow-hidden">
      {/* Simplified Desktop Table View */}
      <div className="hidden md:block overflow-x-auto">
        <table className="w-full">
          <thead className="bg-muted/30">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-medium text-foreground">
                Datum
              </th>
              <th className="px-3 py-3 text-left text-sm font-medium text-foreground">
                Kom
              </th>
              <th className="px-3 py-3 text-left text-sm font-medium text-foreground">
                Gick
              </th>
              <th className="px-3 py-3 text-left text-sm font-medium text-foreground">
                Lunch
              </th>
              <th className="px-3 py-3 text-left text-sm font-medium text-foreground">
                Tid/dag
              </th>
              <th className="px-3 py-3 text-left text-sm font-medium text-foreground">
                Flex +/-
              </th>
              <th className="px-3 py-3 text-left text-sm font-medium text-foreground">
                Saldo
              </th>
              <th className="px-3 py-3 text-left text-sm font-medium text-foreground">
                Anteckningar
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {timeEntries.map((entry, index) => (
              <tr key={`${entry.date}-${index}`} className={getRowClassName(entry, index)}>
                <td className="px-4 py-3">
                  <div className="flex flex-col">
                    <span className="font-semibold text-foreground">{entry.date}</span>
                    <span className="text-xs text-muted-foreground">{entry.weekday}</span>
                  </div>
                </td>
                <td className="px-3 py-3">
                  <Input
                    type="time"
                    value={entry.arrival || ''}
                    onChange={(e) => handleInputChange(index, 'arrival', e.target.value)}
                    className="w-20 text-sm border-input focus:ring-primary focus:border-primary"
                  />
                </td>
                <td className="px-3 py-3">
                  <Input
                    type="time"
                    value={entry.departure || ''}
                    onChange={(e) => handleInputChange(index, 'departure', e.target.value)}
                    className="w-20 text-sm border-input focus:ring-primary focus:border-primary"
                  />
                </td>
                <td className="px-3 py-3">
                  <div className="flex space-x-1">
                    <Input
                      type="time"
                      value={entry.lunchOut || ''}
                      onChange={(e) => handleInputChange(index, 'lunchOut', e.target.value)}
                      className="w-16 text-xs border-input focus:ring-primary focus:border-primary"
                      placeholder="UT"
                    />
                    <Input
                      type="time"
                      value={entry.lunchIn || ''}
                      onChange={(e) => handleInputChange(index, 'lunchIn', e.target.value)}
                      className="w-16 text-xs border-input focus:ring-primary focus:border-primary"
                      placeholder="IN"
                    />
                  </div>
                </td>
                <td className="px-3 py-3 text-center">
                  <span className="text-sm font-mono font-medium text-foreground">
                    {entry.dailyTime}
                  </span>
                </td>
                <td className="px-3 py-3 text-center">
                  <span className={`text-sm font-mono font-semibold ${getBalanceClass(entry.dailyFlex)}`}>
                    {entry.dailyFlex}
                  </span>
                </td>
                <td className="px-3 py-3 text-center">
                  <span className={`text-sm font-mono font-semibold ${getBalanceClass(entry.balance)}`}>
                    {entry.balance}
                  </span>
                </td>
                <td className="px-3 py-3">
                  <Input
                    type="text"
                    value={entry.notes || ''}
                    onChange={(e) => handleInputChange(index, 'notes', e.target.value)}
                    placeholder="Anteckning..."
                    className="w-full text-sm border-input focus:ring-primary focus:border-primary"
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {/* Mobile Card View */}
      <div className="lg:hidden">
        <CardContent className="p-0">
          {timeEntries.map((entry, index) => (
            <div key={`mobile-${entry.date}-${index}`} className="p-4 border-b border-border last:border-b-0">
              <div className="flex justify-between items-center mb-3">
                <div className="flex items-center space-x-3">
                  <span className="font-semibold text-foreground">{entry.date}</span>
                  <span className="text-sm text-muted-foreground">{entry.weekday}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className={`text-sm font-mono font-medium ${getBalanceClass(entry.dailyFlex)}`}>
                    {entry.dailyFlex}
                  </span>
                  <span className={`text-sm font-mono font-medium ${getBalanceClass(entry.balance)}`}>
                    {entry.balance}
                  </span>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs font-medium text-muted-foreground">Kom</Label>
                  <Input
                    type="time"
                    value={entry.arrival || ''}
                    onChange={(e) => handleInputChange(index, 'arrival', e.target.value)}
                    className="mt-1 w-full text-sm border-input focus:ring-primary focus:border-primary"
                  />
                </div>
                <div>
                  <Label className="text-xs font-medium text-muted-foreground">Gick</Label>
                  <Input
                    type="time"
                    value={entry.departure || ''}
                    onChange={(e) => handleInputChange(index, 'departure', e.target.value)}
                    className="mt-1 w-full text-sm border-input focus:ring-primary focus:border-primary"
                  />
                </div>
                <div>
                  <Label className="text-xs font-medium text-muted-foreground">Lunch UT</Label>
                  <Input
                    type="time"
                    value={entry.lunchOut || ''}
                    onChange={(e) => handleInputChange(index, 'lunchOut', e.target.value)}
                    className="mt-1 w-full text-sm border-input focus:ring-primary focus:border-primary"
                  />
                </div>
                <div>
                  <Label className="text-xs font-medium text-muted-foreground">Lunch IN</Label>
                  <Input
                    type="time"
                    value={entry.lunchIn || ''}
                    onChange={(e) => handleInputChange(index, 'lunchIn', e.target.value)}
                    className="mt-1 w-full text-sm border-input focus:ring-primary focus:border-primary"
                  />
                </div>
              </div>
              
              <div className="mt-3">
                <Label className="text-xs font-medium text-muted-foreground">Anmärkningar</Label>
                <Input
                  type="text"
                  value={entry.notes || ''}
                  onChange={(e) => handleInputChange(index, 'notes', e.target.value)}
                  placeholder="Kommentar..."
                  className="mt-1 w-full text-sm border-input focus:ring-primary focus:border-primary"
                />
              </div>
            </div>
          ))}
        </CardContent>
      </div>
    </Card>
  );
}
