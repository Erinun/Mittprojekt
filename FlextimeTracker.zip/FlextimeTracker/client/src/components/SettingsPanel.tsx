import { X, Download, Upload, Trash2 } from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Separator } from '@/components/ui/separator';
import { Settings } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { DataManager } from '@/lib/dataManager';

interface SettingsPanelProps {
  isOpen: boolean;
  onClose: () => void;
  settings: Settings;
  onUpdateSettings: (settings: Partial<Settings>) => void;
  onExportCSV: () => void;
  onClearData: () => void;
}

export function SettingsPanel({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onExportCSV,
  onClearData,
}: SettingsPanelProps) {
  const { toast } = useToast();
  const [localSettings, setLocalSettings] = useState(settings);

  const handleSave = () => {
    onUpdateSettings(localSettings);
    onClose();
  };

  const handleInputChange = (field: keyof Settings, value: string) => {
    setLocalSettings(prev => ({ ...prev, [field]: value }));
  };

  const handleClearData = () => {
    if (window.confirm('Är du säker på att du vill rensa all data? Detta kan inte ångras.')) {
      const success = DataManager.clearAllData();
      if (success) {
        toast({
          title: "Data rensad",
          description: "All flextidsdata har rensats",
        });
        onClearData();
      } else {
        toast({
          title: "Fel",
          description: "Kunde inte rensa data",
          variant: "destructive",
        });
      }
    }
  };

  const handleImportData = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.csv';
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        try {
          await DataManager.importFromCSV(file);
          toast({
            title: "Import slutförd",
            description: "Data har importerats framgångsrikt",
          });
        } catch (error) {
          toast({
            title: "Import misslyckades",
            description: "Kunde inte importera data från filen",
            variant: "destructive",
          });
        }
      }
    };
    input.click();
  };

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent className="w-full max-w-md">
        <SheetHeader>
          <SheetTitle className="flex items-center justify-between">
            Inställningar
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </SheetTitle>
        </SheetHeader>
        
        <div className="py-6 space-y-6">
          <div className="space-y-4">
            <div>
              <Label htmlFor="startingBalance" className="text-sm font-medium text-foreground">
                Ingående saldo
              </Label>
              <Input
                id="startingBalance"
                type="text"
                value={localSettings.startingBalance}
                onChange={(e) => handleInputChange('startingBalance', e.target.value)}
                placeholder="±HH:MM"
                className="mt-1 border-input focus:ring-primary focus:border-primary"
              />
              <p className="mt-1 text-xs text-muted-foreground">
                Format: +4:30 eller -2:15
              </p>
            </div>
            
            <div>
              <Label htmlFor="normalWorkTime" className="text-sm font-medium text-foreground">
                Normalarbetstid per dag
              </Label>
              <Input
                id="normalWorkTime"
                type="text"
                value={localSettings.normalWorkTime}
                onChange={(e) => handleInputChange('normalWorkTime', e.target.value)}
                className="mt-1 border-input focus:ring-primary focus:border-primary"
              />
            </div>
            
            <div>
              <Label htmlFor="defaultLunchTime" className="text-sm font-medium text-foreground">
                Standard lunchtid
              </Label>
              <Input
                id="defaultLunchTime"
                type="text"
                value={localSettings.defaultLunchTime}
                onChange={(e) => handleInputChange('defaultLunchTime', e.target.value)}
                className="mt-1 border-input focus:ring-primary focus:border-primary"
              />
            </div>

            <div className="flex space-x-2">
              <Button onClick={handleSave} className="flex-1">
                Spara inställningar
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setLocalSettings(settings)}
                className="flex-1"
              >
                Återställ
              </Button>
            </div>
          </div>
          
          <Separator />
          
          <div>
            <h4 className="text-sm font-medium text-foreground mb-3">Datahantering</h4>
            <div className="space-y-3">
              <Button
                variant="outline"
                onClick={onExportCSV}
                className="w-full justify-start text-primary border-primary hover:bg-primary hover:text-primary-foreground"
              >
                <Download className="h-4 w-4 mr-2" />
                Exportera till CSV
              </Button>
              
              <Button
                variant="outline"
                onClick={handleImportData}
                className="w-full justify-start text-muted-foreground border-input hover:bg-secondary"
              >
                <Upload className="h-4 w-4 mr-2" />
                Importera data
              </Button>
              
              <Button
                variant="outline"
                onClick={handleClearData}
                className="w-full justify-start text-danger border-danger hover:bg-danger hover:text-white"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Rensa all data
              </Button>
            </div>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
