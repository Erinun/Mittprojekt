import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Search, Calendar, ArrowRight } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface QuickSearchDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onDateSelect: (date: Date) => void;
  currentYear: number;
  currentMonth: number;
}

export function QuickSearchDialog({
  isOpen,
  onClose,
  onDateSelect,
  currentYear,
  currentMonth
}: QuickSearchDialogProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [suggestions, setSuggestions] = useState<Date[]>([]);

  const generateSuggestions = (term: string) => {
    if (!term) {
      // Show common quick options
      const today = new Date();
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);
      const weekAgo = new Date(today);
      weekAgo.setDate(weekAgo.getDate() - 7);
      
      return [today, yesterday, weekAgo];
    }

    const suggestions: Date[] = [];
    
    // Try to parse various date formats
    const formats = [
      // YYYY-MM-DD
      /^(\d{4})-(\d{1,2})-(\d{1,2})$/,
      // DD/MM/YYYY or DD-MM-YYYY
      /^(\d{1,2})[-/](\d{1,2})[-/](\d{4})$/,
      // DD/MM or DD-MM (current year)
      /^(\d{1,2})[-/](\d{1,2})$/,
      // Just day number (current month/year)
      /^(\d{1,2})$/
    ];

    formats.forEach((format, index) => {
      const match = term.match(format);
      if (match) {
        let year, month, day;
        
        switch (index) {
          case 0: // YYYY-MM-DD
            year = parseInt(match[1]);
            month = parseInt(match[2]) - 1;
            day = parseInt(match[3]);
            break;
          case 1: // DD/MM/YYYY
            day = parseInt(match[1]);
            month = parseInt(match[2]) - 1;
            year = parseInt(match[3]);
            break;
          case 2: // DD/MM (current year)
            day = parseInt(match[1]);
            month = parseInt(match[2]) - 1;
            year = currentYear;
            break;
          case 3: // Just day
            day = parseInt(match[1]);
            month = currentMonth;
            year = currentYear;
            break;
        }
        
        const date = new Date(year!, month!, day!);
        if (!isNaN(date.getTime()) && day! <= 31 && month! <= 11) {
          suggestions.push(date);
        }
      }
    });

    // Text-based search (Swedish)
    const textMatches = [
      { terms: ['idag', 'today'], date: new Date() },
      { terms: ['igår', 'yesterday'], date: new Date(Date.now() - 24 * 60 * 60 * 1000) },
      { terms: ['imorgon', 'tomorrow'], date: new Date(Date.now() + 24 * 60 * 60 * 1000) }
    ];

    textMatches.forEach(({ terms, date }) => {
      if (terms.some(term => term.toLowerCase().includes(searchTerm.toLowerCase()))) {
        suggestions.push(date);
      }
    });

    return suggestions.slice(0, 5); // Limit to 5 suggestions
  };

  useEffect(() => {
    setSuggestions(generateSuggestions(searchTerm));
  }, [searchTerm, currentYear, currentMonth]);

  const handleDateSelect = (date: Date) => {
    onDateSelect(date);
    onClose();
    setSearchTerm('');
  };

  const formatDateDisplay = (date: Date) => {
    const today = new Date();
    const isToday = date.toDateString() === today.toDateString();
    const isYesterday = date.toDateString() === new Date(Date.now() - 24 * 60 * 60 * 1000).toDateString();
    const isTomorrow = date.toDateString() === new Date(Date.now() + 24 * 60 * 60 * 1000).toDateString();

    if (isToday) return 'Idag';
    if (isYesterday) return 'Igår';
    if (isTomorrow) return 'Imorgon';

    return date.toLocaleDateString('sv-SE', { 
      weekday: 'short', 
      day: 'numeric', 
      month: 'short',
      year: date.getFullYear() !== today.getFullYear() ? 'numeric' : undefined
    });
  };

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (!isOpen) {
          // This would be handled by parent component
        }
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Search className="h-5 w-5" />
            <span>Hoppa till datum</span>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Skriv datum (YYYY-MM-DD, DD/MM, eller 'idag')"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 rounded-xl"
              autoFocus
            />
          </div>

          {suggestions.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-2"
            >
              <p className="text-sm text-muted-foreground">Förslag:</p>
              {suggestions.map((date, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <Button
                    variant="ghost"
                    onClick={() => handleDateSelect(date)}
                    className="w-full justify-between rounded-xl hover:bg-muted"
                  >
                    <div className="flex items-center space-x-3">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span>{formatDateDisplay(date)}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant="secondary" className="text-xs">
                        {date.toLocaleDateString('sv-SE')}
                      </Badge>
                      <ArrowRight className="h-4 w-4 text-muted-foreground" />
                    </div>
                  </Button>
                </motion.div>
              ))}
            </motion.div>
          )}

          <div className="text-xs text-muted-foreground space-y-1">
            <p>Exempel:</p>
            <ul className="space-y-1 pl-4">
              <li>• "2024-01-15" eller "15/01/2024"</li>
              <li>• "15" för dag 15 denna månad</li>
              <li>• "idag", "igår", "imorgon"</li>
            </ul>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}