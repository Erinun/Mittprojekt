import { motion } from 'framer-motion';
import { Calendar, Clock } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { CalculatedTimeEntry } from '@shared/schema';
import { FlexTimeCalculator } from '@/lib/flexCalculations';
import { DateHelpers } from '@/lib/dateHelpers';

interface DayCardProps {
  day: CalculatedTimeEntry;
  dayIndex: number;
  onUpdateEntry: (dayIndex: number, field: keyof CalculatedTimeEntry, value: string) => void;
  currentYear: number;
  currentMonth: number;
}

export function DayCard({
  day,
  dayIndex,
  onUpdateEntry,
  currentYear,
  currentMonth
}: DayCardProps) {
  const isToday = DateHelpers.isToday(day.date, currentYear, currentMonth);
  const isWeekend = DateHelpers.isWeekend(day.date, currentYear, currentMonth);
  
  const getBalanceBadgeClass = (balance: string) => {
    const minutes = FlexTimeCalculator.parseTime(balance);
    if (minutes > 0) return 'bg-green-50 text-green-700 border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-800';
    if (minutes < 0) return 'bg-red-50 text-red-700 border-red-200 dark:bg-red-900/20 dark:text-red-400 dark:border-red-800';
    return 'bg-gray-50 text-gray-600 border-gray-200 dark:bg-gray-800/20 dark:text-gray-400 dark:border-gray-700';
  };

  const handleFieldUpdate = (field: keyof CalculatedTimeEntry, value: string) => {
    onUpdateEntry(dayIndex, field, value);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 5 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: dayIndex * 0.05 }}
      className={`
        card-surface p-4 transition-all duration-200
        ${isToday ? 'ring-2 ring-primary bg-blue-50/50 dark:bg-blue-900/10' : 'hover:bg-surface'}
        ${isWeekend ? 'bg-gray-50/50 dark:bg-gray-800/10' : ''}
        min-h-[120px]
      `}
    >
      {/* Mobile Layout */}
      <div className="lg:hidden space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className={`p-2 rounded-lg ${isToday ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}>
              <Calendar className="h-4 w-4" />
            </div>
            <div>
              <h4 className="font-semibold text-foreground">{day.weekday}</h4>
              <p className="text-sm text-muted-foreground">{day.date.split(' ')[0]}</p>
            </div>
          </div>
          <Badge className={`${getBalanceBadgeClass(day.dailyFlex)} px-2 py-1 text-xs font-medium border`}>
            {day.dailyFlex}
          </Badge>
        </div>

        {/* Time Fields */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Ankomst</label>
            <Input
              type="time"
              value={day.arrival || ''}
              onChange={(e) => handleFieldUpdate('arrival', e.target.value)}
              className="input-field h-9 text-sm"
            />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Avgång</label>
            <Input
              type="time"
              value={day.departure || ''}
              onChange={(e) => handleFieldUpdate('departure', e.target.value)}
              className="input-field h-9 text-sm"
            />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Lunch ut</label>
            <Input
              type="time"
              value={day.lunchOut || ''}
              onChange={(e) => handleFieldUpdate('lunchOut', e.target.value)}
              className="input-field h-9 text-sm"
            />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Lunch in</label>
            <Input
              type="time"
              value={day.lunchIn || ''}
              onChange={(e) => handleFieldUpdate('lunchIn', e.target.value)}
              className="input-field h-9 text-sm"
            />
          </div>
        </div>

        {/* Summary */}
        <div className="flex items-center justify-between pt-2 border-t border-border">
          <div className="flex items-center space-x-2">
            <Clock className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm font-medium text-foreground">{day.dailyTime}</span>
          </div>
          <Badge className={`${getBalanceBadgeClass(day.balance)} px-2 py-1 text-xs font-medium border`}>
            Saldo: {day.balance}
          </Badge>
        </div>
      </div>

      {/* Desktop Layout */}
      <div className="hidden lg:grid lg:grid-cols-2 lg:gap-6 lg:items-center">
        {/* Left Column - Time Fields */}
        <div className="space-y-4">
          <div className="flex items-center space-x-3">
            <div className={`p-2 rounded-lg ${isToday ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}>
              <Calendar className="h-5 w-5" />
            </div>
            <div>
              <h4 className="font-semibold text-foreground">{day.weekday}</h4>
              <p className="text-sm text-muted-foreground">{day.date.split(' ')[0]}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Ankomst</label>
              <Input
                type="time"
                value={day.arrival || ''}
                onChange={(e) => handleFieldUpdate('arrival', e.target.value)}
                className="input-field h-9"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Avgång</label>
              <Input
                type="time"
                value={day.departure || ''}
                onChange={(e) => handleFieldUpdate('departure', e.target.value)}
                className="input-field h-9"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Lunch ut</label>
              <Input
                type="time"
                value={day.lunchOut || ''}
                onChange={(e) => handleFieldUpdate('lunchOut', e.target.value)}
                className="input-field h-9"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Lunch in</label>
              <Input
                type="time"
                value={day.lunchIn || ''}
                onChange={(e) => handleFieldUpdate('lunchIn', e.target.value)}
                className="input-field h-9"
              />
            </div>
          </div>
        </div>

        {/* Right Column - Summary & Notes */}
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-3 bg-muted rounded-lg">
              <div className="text-xs font-medium text-muted-foreground mb-1">Arbetstid</div>
              <div className="text-lg font-semibold text-foreground">{day.dailyTime}</div>
            </div>
            <div className="text-center p-3 bg-muted rounded-lg">
              <div className="text-xs font-medium text-muted-foreground mb-1">Flex idag</div>
              <Badge className={`${getBalanceBadgeClass(day.dailyFlex)} px-2 py-1 font-medium border text-sm`}>
                {day.dailyFlex}
              </Badge>
            </div>
          </div>

          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Anteckningar</label>
            <Input
              type="text"
              placeholder="Kommentarer..."
              value={day.notes || ''}
              onChange={(e) => handleFieldUpdate('notes', e.target.value)}
              className="input-field"
            />
          </div>

          <div className="text-center">
            <Badge className={`${getBalanceBadgeClass(day.balance)} px-3 py-2 font-semibold border text-sm`}>
              Totalsaldo: {day.balance}
            </Badge>
          </div>
        </div>
      </div>
    </motion.div>
  );
}