import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CalculatedTimeEntry } from '@shared/schema';
import { FlexTimeCalculator } from '@/lib/flexCalculations';

interface WeekDayNavProps {
  weekDays: CalculatedTimeEntry[];
  onDayClick: (dayIndex: number) => void;
}

export function WeekDayNav({ weekDays, onDayClick }: WeekDayNavProps) {
  const dayInitials = ['M', 'T', 'O', 'T', 'F', 'L', 'S'];
  const dayNames = ['Mån', 'Tis', 'Ons', 'Tor', 'Fre', 'Lör', 'Sön'];

  const getDayStatusClass = (day: CalculatedTimeEntry) => {
    if (!day.arrival || !day.departure) {
      return 'bg-gray-100 text-gray-400 border-gray-200 dark:bg-gray-800 dark:text-gray-600 dark:border-gray-700';
    }
    
    const flexMinutes = FlexTimeCalculator.parseTime(day.dailyFlex);
    if (flexMinutes > 0) {
      return 'bg-green-50 text-green-700 border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-800';
    }
    if (flexMinutes < 0) {
      return 'bg-red-50 text-red-700 border-red-200 dark:bg-red-900/20 dark:text-red-400 dark:border-red-800';
    }
    return 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-900/20 dark:text-blue-400 dark:border-blue-800';
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex items-center justify-between p-3 bg-muted/30 rounded-lg border border-border"
    >
      <div className="flex items-center space-x-1">
        <span className="text-sm font-medium text-muted-foreground mr-3">
          Snabbnavigation:
        </span>
        {weekDays.map((day, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.05 }}
          >
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onDayClick(index)}
              className={`
                h-8 w-8 p-0 rounded-full border transition-all duration-200
                ${getDayStatusClass(day)}
                hover:scale-105 focus:ring-2 focus:ring-focus
              `}
              title={`${dayNames[index]} - ${day.date.split(' ')[0]}`}
            >
              <span className="text-xs font-semibold">
                {dayInitials[index]}
              </span>
            </Button>
          </motion.div>
        ))}
      </div>

      <div className="hidden sm:flex items-center space-x-2 text-xs text-muted-foreground">
        <div className="flex items-center space-x-1">
          <div className="w-2 h-2 bg-green-400 rounded-full"></div>
          <span>Övertid</span>
        </div>
        <div className="flex items-center space-x-1">
          <div className="w-2 h-2 bg-red-400 rounded-full"></div>
          <span>Minus</span>
        </div>
        <div className="flex items-center space-x-1">
          <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
          <span>Tom</span>
        </div>
      </div>
    </motion.div>
  );
}