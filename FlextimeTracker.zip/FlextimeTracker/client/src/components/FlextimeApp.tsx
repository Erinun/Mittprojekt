import { useState } from 'react';
import { ModernHeader } from './ModernHeader';
import { DatePickerSidebar } from './DatePickerSidebar';
import { QuickFilters } from './QuickFilters';
import { WeekAccordion } from './WeekAccordion';
import { QuickSearchDialog } from './QuickSearchDialog';
import { ModernMonthlySummary } from './ModernMonthlySummary';
import { SettingsPanel } from './SettingsPanel';
import { useFlextime } from '@/hooks/useFlextime';
import { motion } from 'framer-motion';
import { DateHelpers } from '@/lib/dateHelpers';
import { FlexTimeCalculator } from '@/lib/flexCalculations';

export function FlextimeApp() {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>();
  const [activeFilters, setActiveFilters] = useState<string[]>([]);
  const [expandedWeeks, setExpandedWeeks] = useState<Set<number>>(new Set());
  const [isQuickSearchOpen, setIsQuickSearchOpen] = useState(false);
  
  const {
    currentYear,
    currentMonth,
    timeEntries,
    settings,
    isSettingsOpen,
    updateTimeEntry,
    applyQuickEntry,
    applyFlexLeave,
    updateSettings,
    goToPreviousMonth,
    goToNextMonth,
    exportToCSV,
    setIsSettingsOpen,
    monthlyStats,
    currentBalance,
    currentMonthName,
  } = useFlextime();

  const handleDateSelect = (date: Date) => {
    setSelectedDate(date);
    // Navigate to the month containing this date
    if (date.getFullYear() !== currentYear || date.getMonth() !== currentMonth) {
      // This would trigger navigation to the correct month
      // For now, just store the selected date
    }
  };

  const handleMonthChange = (year: number, month: number) => {
    if (year !== currentYear || month !== currentMonth) {
      // Update the current month/year
      if (month < currentMonth || year < currentYear) {
        goToPreviousMonth();
      } else {
        goToNextMonth();
      }
    }
  };

  const handleToggleFilter = (filter: string) => {
    setActiveFilters(prev => 
      prev.includes(filter) 
        ? prev.filter(f => f !== filter)
        : [...prev, filter]
    );
  };

  const handleToggleWeek = (weekNumber: number) => {
    setExpandedWeeks(prev => {
      const newSet = new Set(prev);
      if (newSet.has(weekNumber)) {
        newSet.delete(weekNumber);
      } else {
        newSet.add(weekNumber);
      }
      return newSet;
    });
  };

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    document.documentElement.classList.toggle('dark');
  };

  // Filter time entries based on active filters
  const filteredTimeEntries = timeEntries.filter(entry => {
    if (activeFilters.includes('empty-fields')) {
      return !entry.arrival || !entry.departure;
    }
    if (activeFilters.includes('current-month')) {
      const today = new Date();
      const entryDate = new Date(currentYear, currentMonth, parseInt(entry.date.split(' ')[0]));
      return entryDate.getMonth() === today.getMonth() && entryDate.getFullYear() === today.getFullYear();
    }
    if (activeFilters.includes('last-30-days')) {
      const today = new Date();
      const thirtyDaysAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000);
      const entryDate = new Date(currentYear, currentMonth, parseInt(entry.date.split(' ')[0]));
      return entryDate >= thirtyDaysAgo;
    }
    return true;
  });

  return (
    <div className="min-h-screen bg-background">
      {/* Modern Header */}
      <ModernHeader
        currentMonthName={currentMonthName}
        currentBalance={currentBalance}
        onPreviousMonth={goToPreviousMonth}
        onNextMonth={goToNextMonth}
        onOpenSettings={() => setIsSettingsOpen(true)}
        isDarkMode={isDarkMode}
        onToggleDarkMode={toggleDarkMode}
      />

      <div className="flex h-screen">
        {/* Sidebar with Date Picker */}
        <DatePickerSidebar
          currentYear={currentYear}
          currentMonth={currentMonth}
          onDateSelect={handleDateSelect}
          onMonthChange={handleMonthChange}
          currentBalance={currentBalance}
        />

        {/* Main Content */}
        <main className="flex-1 overflow-hidden">
          <div className="h-full flex flex-col">
            {/* Monthly Summary */}
            <div className="p-6 border-b border-border">
              <ModernMonthlySummary stats={monthlyStats} />
            </div>

            {/* Quick Filters */}
            <div className="p-6 border-b border-border">
              <QuickFilters
                activeFilters={activeFilters}
                onToggleFilter={handleToggleFilter}
                onOpenQuickSearch={() => setIsQuickSearchOpen(true)}
              />
            </div>

            {/* Week Accordion List - Shows all 7 days when expanded */}
            <div className="flex-1 overflow-auto p-6 space-y-4">
              {(() => {
                // Group entries by week
                const weekGroups = filteredTimeEntries.reduce((acc, entry, index) => {
                  const weekNumber = DateHelpers.getWeekNumber(entry.date, currentYear, currentMonth);
                  
                  if (!acc[weekNumber]) {
                    acc[weekNumber] = {
                      weekNumber,
                      days: [],
                      weekBalance: '+0:00'
                    };
                  }
                  
                  acc[weekNumber].days.push({ ...entry, originalIndex: index });
                  return acc;
                }, {} as Record<number, { weekNumber: number; days: any[]; weekBalance: string }>);

                // Calculate week balances
                Object.values(weekGroups).forEach(week => {
                  let totalBalance = 0;
                  week.days.forEach(day => {
                    if (day.dailyFlex) {
                      totalBalance += FlexTimeCalculator.parseTime(day.dailyFlex);
                    }
                  });
                  week.weekBalance = FlexTimeCalculator.formatTime(totalBalance, true);
                });

                const weeks = Object.values(weekGroups).sort((a, b) => a.weekNumber - b.weekNumber);

                return weeks.map((week) => (
                  <WeekAccordion
                    key={week.weekNumber}
                    weekNumber={week.weekNumber}
                    weekDays={week.days}
                    weekBalance={week.weekBalance}
                    onUpdateEntry={(dayIndex: number, field: any, value: string) => {
                      const day = week.days[dayIndex];
                      if (day && day.originalIndex !== undefined) {
                        updateTimeEntry(day.originalIndex, field, value);
                      }
                    }}
                    currentYear={currentYear}
                    currentMonth={currentMonth}
                    isExpanded={expandedWeeks.has(week.weekNumber)}
                    onToggle={() => handleToggleWeek(week.weekNumber)}
                  />
                ));
              })()}
            </div>
          </div>
        </main>
      </div>

      {/* Quick Search Dialog */}
      <QuickSearchDialog
        isOpen={isQuickSearchOpen}
        onClose={() => setIsQuickSearchOpen(false)}
        onDateSelect={handleDateSelect}
        currentYear={currentYear}
        currentMonth={currentMonth}
      />

      {/* Settings Panel */}
      <SettingsPanel
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={updateSettings}
        onExportCSV={exportToCSV}
        onClearData={() => {
          console.log('Clear data requested');
        }}
      />
    </div>
  );
}
