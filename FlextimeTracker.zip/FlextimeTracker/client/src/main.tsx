import { createRoot } from "react-dom/client";
import App from "./App";
import "./styles-blue.css";
import "./force-blue.css";
import "./force-dark.css";

createRoot(document.getElementById("root")!).render(<App />);
